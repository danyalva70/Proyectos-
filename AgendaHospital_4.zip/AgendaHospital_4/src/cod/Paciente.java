/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cod;

import cod.Conexion;
import java.sql.ResultSet;

/**
 *
 * @author danya
 */
public class Paciente implements menu{
       private String consulta;
    private String Mensaje;
    private Conexion con;
    private String Nombre;
    private String Direccion;
    private String Telefono;
    private boolean Estado;
    private String edad;
    private String apellido;
    private String expediente;
    

    public Paciente() {
        con = new Conexion();
    }
    public String getMensaje() {
        return Mensaje;
    }

    public String getapellido() {
        return apellido;
    }

    public void setapellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }
        public String getExpediente() {
        return expediente;
    }

    public void setExpediente(String expediente) {
        this.expediente = expediente;
    }
    
        public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }
    

    public boolean isEstado() {
        return Estado;
    }

    public void setEstado(boolean Estado) {
        this.Estado = Estado;
    }
    

   @Override
    public boolean Guardar() {
        try {
            consulta = "insert into pacientes (Expedientes, Nombre, Apellido, Edad,Direccion, Telefono, Estado) values "
                    + "('" + expediente + "', '" + Nombre +"', '" + apellido +"', '" + edad + "', '" + Direccion + "', '" + Telefono + "', " + Estado + ")";
            String respuesta = con.Ejecutar(consulta);
            if (respuesta.equals("")) {
                return true;
            } else {
                Mensaje = "Error la informacion no se guardo, " + respuesta;
                return false;
            }
        } catch (Exception x) {
            Mensaje = "Error la informacion no se guardo, " + x.toString();
            return false;
        }
    }

    @Override
    public ResultSet verInformacion() {
        try {
            ResultSet rs;
            rs = con.EjecutarConsulta("SELECT Expedentes, Nombre, Apoellido, Edad, direccion, telefono, estado from pacientes ");
            return rs;
        } catch (Exception x) {
            return null;
        }
    }

    @Override
    public boolean Borrar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean Actualizar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
   
        

    
}
