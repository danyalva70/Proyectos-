/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cod;
import cod.Conexion;
import java.sql.ResultSet;
/**
 *
 * @author danya
 */
public class medico implements menu{
              private String consulta;
    private String Mensaje;
    private Conexion con;
    private String especialidad;
    private String Nombre;
    private String apellido;
    private boolean Estado;
    private String salario;
        private String Telefono;

    

    public medico() {
        con = new Conexion();
    }
    public String getMensaje() {
        return Mensaje;
    }

    public String getapellido() {
        return apellido;
    }

    public void setapellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }
        public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
    
    public boolean isEstado() {
        return Estado;
    }

    public void setEstado(boolean Estado) {
        this.Estado = Estado;
    }
    

   @Override
    public boolean Guardar() {
        try {
            consulta = "insert into doctores (especialidad, Nombre, Apellido, estado, salario, Telefono, ) values "
                    + "('" + especialidad + "', '" + Nombre +"', '" + apellido +"', '" + Estado + "', '" + salario + "', '" + Telefono +  ")";
            String respuesta = con.Ejecutar(consulta);
            if (respuesta.equals("")) {
                return true;
            } else {
                Mensaje = "Error la informacion no se guardo, " + respuesta;
                return false;
            }
        } catch (Exception x) {
            Mensaje = "Error la informacion no se guardo, " + x.toString();
            return false;
        }
    }

    @Override
    public ResultSet verInformacion() {
        try {
            ResultSet rs;
            rs = con.EjecutarConsulta("SELECT especialidad, Nombre, Apoellido, Estado, salario, telefono from doctores ");
            return rs;
        } catch (Exception x) {
            return null;
        }
    }

    @Override
    public boolean Borrar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean Actualizar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
   
        

    
}
