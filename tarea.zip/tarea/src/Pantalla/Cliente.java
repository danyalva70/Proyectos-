/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Pantalla;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author danya
 */
public class Cliente extends javax.swing.JFrame {
    DefaultTableModel modelo;
    
    /**
     * Creates new form Cliente
     */
    public Cliente() {
          initComponents();
        modelo = new DefaultTableModel();
        modeloTabla();
    }
    
     private void modeloTabla() {
        // Definir el modelo para la tabla con los nombres de las columnas
        modelo.addColumn("Código");
        modelo.addColumn("Nombre");
        modelo.addColumn("Precio Venta");
        modelo.addColumn("Precio Costo");
        modelo.addColumn("Activo");
        modelo.addColumn("Clasificación");

        tbl.setModel(modelo);
    }
     
      private int contador = 1; // Inicializa el contador para el segundo número.

private void AgregarInformacion() {
    // Obtén los valores de los campos
    String nombre = txtnombre.getText();
    String precioVenta = txtprecioventa.getText();
    String precioCosto = txtpreciocosto.getText();
    String activo = txtactivo.getText();
    String clasificacion = cmbClasificacion.getSelectedItem().toString();

    // Valida que los campos no estén vacíos
    if (nombre.isEmpty() || precioVenta.isEmpty() || precioCosto.isEmpty() || activo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos");
        return;
    }

    // Genera el código según la lógica solicitada
    String codigo = generarCodigo(nombre, precioCosto, precioVenta, clasificacion);
  

    // Agrega la información a la tabla
    DefaultTableModel model = (DefaultTableModel) tbl.getModel();
    model.addRow(new Object[]{codigo, nombre, precioVenta, precioCosto, clasificacion, activo});
}

private String generarCodigo(String nombre, String precioCosto, String precioVenta, String clasificacion) {
    // Verifica que nombre tenga al menos 3 caracteres
    char terceraLetra = (nombre.length() >= 3) ? nombre.charAt(2) : 'X';  // Si no tiene 3 caracteres, usa 'X' por defecto

    // Obtén el primer dígito del precioCosto y precioVenta
    char primerDigitoCosto = obtenerPrimerNumero(precioCosto);
    char primerDigitoVenta = obtenerPrimerNumero(precioVenta);

    // Concatena la clasificación y el contador
    String codigoGenerado = "" + terceraLetra + primerDigitoCosto + primerDigitoVenta + clasificacion + contador;

    contador++; // Incrementa el contador para el siguiente código
    return codigoGenerado;
}

// Método para obtener el primer número de una cadena
private char obtenerPrimerNumero(String texto) {
    for (char c : texto.toCharArray()) {
        if (Character.isDigit(c)) {
            return c;
        }
    }
    return '0'; // Devuelve '0' si no encuentra un número
}


    // Método para seleccionar una fila y mostrar los datos en los campos
private void SelectRow() {
    int selectedRow = tbl.getSelectedRow();
    if (selectedRow >= 0) {
        // txtcod.setText(modelo.getValueAt(selectedRow, 0).toString()); // Elimina esta línea si ya no usas txtcod.
        txtnombre.setText(modelo.getValueAt(selectedRow, 1).toString());
        txtprecioventa.setText(modelo.getValueAt(selectedRow, 2).toString());
        txtpreciocosto.setText(modelo.getValueAt(selectedRow, 3).toString());
        txtactivo.setText(modelo.getValueAt(selectedRow, 4).toString());
        cmbClasificacion.setSelectedItem(modelo.getValueAt(selectedRow, 5).toString());
    }
}

    // Método para limpiar los campos
    private void limpiarCampos() {
        
        txtnombre.setText("");
        txtprecioventa.setText("");
        txtpreciocosto.setText("");
        txtactivo.setText("");
        cmbClasificacion.setSelectedIndex(0);
    }
    
    private void ActualizarInformacion() {
    // Obtener los valores de los campos de texto
    String nombre = txtnombre.getText();
    String precioVentaStr = txtprecioventa.getText();
    String precioCostoStr = txtpreciocosto.getText();
    String activo = txtactivo.getText();
    String clasificacion = cmbClasificacion.getSelectedItem().toString();

    // Validar que los campos de precio venta y costo contengan números válidos
    try {
        double precioVenta = Double.parseDouble(precioVentaStr);
        double precioCosto = Double.parseDouble(precioCostoStr);
        
        // Verificar que el precio de venta no sea menor que el costo
        if (precioVenta < precioCosto) {
            javax.swing.JOptionPane.showMessageDialog(this, "El precio de venta no puede ser menor que el costo.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtener la fila seleccionada
        int selectedRow = tbl.getSelectedRow();
        
        if (selectedRow >= 0) {
            // Actualizar los valores en la tabla con los nuevos datos ingresados en los campos de texto
            modelo.setValueAt(nombre, selectedRow, 1);
            modelo.setValueAt(precioVentaStr, selectedRow, 2);
            modelo.setValueAt(precioCostoStr, selectedRow, 3);
            modelo.setValueAt(activo, selectedRow, 4);
            modelo.setValueAt(clasificacion, selectedRow, 5);
            
            // Mensaje de confirmación
            javax.swing.JOptionPane.showMessageDialog(this, "Datos actualizados correctamente.");
        } else {
            // Mensaje si no se ha seleccionado ninguna fila
            javax.swing.JOptionPane.showMessageDialog(this, "Por favor selecciona una fila para actualizar.");
        }
    } catch (NumberFormatException e) {
        // Manejar el error si los campos de precio no contienen números válidos
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor ingresa valores válidos para el precio de venta y el costo.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblapellido = new javax.swing.JLabel();
        lblciclo = new javax.swing.JLabel();
        lblsec = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        txtprecioventa = new javax.swing.JTextField();
        txtpreciocosto = new javax.swing.JTextField();
        txtactivo = new javax.swing.JTextField();
        lblsec2 = new javax.swing.JLabel();
        btbAgregar = new javax.swing.JButton();
        cmbClasificacion = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl = new javax.swing.JTable();
        btnActualizar = new javax.swing.JButton();
        lblnombre = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblapellido.setText("Precio de Venta:");

        lblciclo.setText("Precio Costo:");

        lblsec.setText("Activo:");

        txtnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnombreActionPerformed(evt);
            }
        });

        lblsec2.setText("Clasificación:");

        btbAgregar.setText("Agregar");
        btbAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbAgregarActionPerformed(evt);
            }
        });

        cmbClasificacion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A", "B", "C" }));

        tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl);

        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        lblnombre.setText("Nombre:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(lblapellido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblciclo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblsec, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblnombre, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblsec2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtactivo)
                                .addComponent(txtnombre)
                                .addComponent(txtprecioventa)
                                .addComponent(txtpreciocosto, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cmbClasificacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnActualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btbAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblnombre)
                    .addComponent(txtnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblapellido)
                    .addComponent(txtprecioventa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblciclo)
                    .addComponent(txtpreciocosto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblsec)
                        .addComponent(txtactivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btbAgregar))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblsec2)
                            .addComponent(cmbClasificacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(btnActualizar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btbAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbAgregarActionPerformed
        AgregarInformacion();
        limpiarCampos();// TODO add your handling code here:
    }//GEN-LAST:event_btbAgregarActionPerformed

    private void tblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblMouseClicked
        SelectRow();        // TODO add your handling code here:
    }//GEN-LAST:event_tblMouseClicked

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        ActualizarInformacion();
        limpiarCampos();// TODO add your handling code here:
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void txtnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnombreActionPerformed
 private void btbagregarActionPerformed() {                                           
        AgregarInformacion();    
        limpiarCampos();// TODO add your handling code here:
    }                                          

    private void tblmouseClicked() {                                 
        SelectRow();        // TODO add your handling code here:
    }                                

    private void btnactualizarActionPerformed() {                                              
       ActualizarInformacion(); 
       limpiarCampos();// TODO add your handling code here:
    }        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Cliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbAgregar;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JComboBox<String> cmbClasificacion;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblapellido;
    private javax.swing.JLabel lblciclo;
    private javax.swing.JLabel lblnombre;
    private javax.swing.JLabel lblsec;
    private javax.swing.JLabel lblsec2;
    private javax.swing.JTable tbl;
    private javax.swing.JTextField txtactivo;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtpreciocosto;
    private javax.swing.JTextField txtprecioventa;
    // End of variables declaration//GEN-END:variables
}
