/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Entidad;

/**
 *
 * @author danya
 */
public interface menu {
    public boolean guardar();
    public boolean actualizar();
    public boolean borrar();
    public void mostrar();
}
