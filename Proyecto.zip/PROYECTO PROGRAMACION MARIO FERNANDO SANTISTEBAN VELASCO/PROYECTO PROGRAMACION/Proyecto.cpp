#include <iostream>
#include <string>
#include <fstream>
#include <sstream> // A�adir este encabezado para utilizar istringstream

using namespace std;

// Estructura para representar una compra
struct Compra {
    int codigoProveedor;
    double pesoCilindro;
    int cantidadCilindros;
    double precioUnitario;
    string nombreProveedor;
    string fechaCompra;
};

// Estructura para representar una venta
struct Venta {
    int codigoCliente;
    string tipoCliente;
    string nombreCliente;
    double pesoCilindro;
    int cantidadCilindros;
    double precioUnitario;
    string fechaVenta;
    string tipoVenta; // "credito" o "contado"
    string fechaPago; // Fecha de pago en caso de venta a cr�dito
    int puntosAcumulados; //  puntos acumulados
};

// Estructura para representar un cliente
struct Cliente {
    int codigoCliente;
    string tipoCliente;
    string nombreCliente;
    string fechaPago;
    int puntosAcumulados;
};

void registrarCliente() {
    Cliente nuevoCliente;

    cout << "Ingrese el codigo del cliente: ";
    cin >> nuevoCliente.codigoCliente;

    cout << "Ingrese el tipo de cliente: ";
    cin.ignore();
    getline(cin, nuevoCliente.tipoCliente);

    cout << "Ingrese el nombre del cliente: ";
    getline(cin, nuevoCliente.nombreCliente);

    cout << "Ingrese la fecha de pago (DD/MM/AAAA): ";
    getline(cin, nuevoCliente.fechaPago);

    cout << "Ingrese los puntos acumulados: ";
    cin >> nuevoCliente.puntosAcumulados;

    // Guardar el cliente en el archivo
    ofstream archivoClientes("clientes.txt", ios::app);
    if (!archivoClientes) {
        cerr << "No se pudo abrir el archivo de clientes." << endl;
        return;
    }

    archivoClientes << nuevoCliente.codigoCliente << " "
                    << nuevoCliente.tipoCliente << " "
                    << nuevoCliente.nombreCliente << " "
                    << nuevoCliente.fechaPago << " "
                    << nuevoCliente.puntosAcumulados << endl;

    archivoClientes.close();

    cout << "El cliente ha sido registrado exitosamente." << endl;
}

// Funci�n para registrar una compra
void registrarCompra() {
    Compra nuevaCompra;

    cout << "Ingrese el codigo del proveedor: ";
    cin >> nuevaCompra.codigoProveedor;

    cout << "Ingrese el peso del cilindro: ";
    cin >> nuevaCompra.pesoCilindro;

    cout << "Ingrese la cantidad de cilindros: ";
    cin >> nuevaCompra.cantidadCilindros;

    cout << "Ingrese el precio unitario del cilindro: ";
    cin >> nuevaCompra.precioUnitario;

    cout << "Ingrese el nombre del proveedor: ";
    cin.ignore(); // Limpiar el buffer del teclado
    getline(cin, nuevaCompra.nombreProveedor);

    cout << "Ingrese la fecha de la compra (DD/MM/AAAA): ";
    cin >> nuevaCompra.fechaCompra;

    // Guardar la compra en el archivo
    ofstream archivoCompras("compras.txt", ios::app);
    if (!archivoCompras) {
        cerr << "No se pudo abrir el archivo de compras." << endl;
        return;
    }

    archivoCompras << nuevaCompra.codigoProveedor << " "
                   << nuevaCompra.pesoCilindro << " "
                   << nuevaCompra.cantidadCilindros << " "
                   << nuevaCompra.precioUnitario << " "
                   << nuevaCompra.nombreProveedor << " "
                   << nuevaCompra.fechaCompra << endl;

    archivoCompras.close();

    cout << "La compra ha sido registrada exitosamente." << endl;
}

// Funci�n para registrar una venta
void registrarVenta() {
    Venta nuevaVenta;

    cout << "Ingrese el c�digo del cliente: ";
    cin >> nuevaVenta.codigoCliente;

    cout << "Ingrese el tipo de cliente (particular, restaurante, empresa, etc.): ";
    cin.ignore();
    getline(cin, nuevaVenta.tipoCliente);

    cout << "Ingrese el nombre del cliente: ";
    getline(cin, nuevaVenta.nombreCliente);

    cout << "Ingrese el peso del cilindro: ";
    cin >> nuevaVenta.pesoCilindro;

    cout << "Ingrese la cantidad de cilindros: ";
    cin >> nuevaVenta.cantidadCilindros;

    cout << "Ingrese el precio unitario del cilindro: ";
    cin >> nuevaVenta.precioUnitario;

    cout << "Ingrese la fecha de la venta (DD/MM/AAAA): ";
    cin >> nuevaVenta.fechaVenta;

    cout << "Ingrese el tipo de venta (credito/contado): ";
    cin >> nuevaVenta.tipoVenta;

    if (nuevaVenta.tipoVenta == "credito") {
        cout << "Ingrese la fecha de pago (DD/MM/AAAA): ";
        cin >> nuevaVenta.fechaPago;
    } else {
        nuevaVenta.fechaPago = "NULL";
    }

    cout << "Ingrese los puntos acumulados: ";
    cin >> nuevaVenta.puntosAcumulados;

    // Guardar la venta en el archivo
    ofstream archivoVentas("ventas.txt", ios::app);
    if (!archivoVentas) {
        cerr << "No se pudo abrir el archivo de ventas." << endl;
        return;
    }

    archivoVentas << nuevaVenta.codigoCliente << " "
                  << nuevaVenta.tipoCliente << " "
                  << nuevaVenta.nombreCliente << " "
                  << nuevaVenta.pesoCilindro << " "
                  << nuevaVenta.cantidadCilindros << " "
                  << nuevaVenta.precioUnitario << " "
                  << nuevaVenta.fechaVenta << " "
                  << nuevaVenta.tipoVenta << " "
                  << nuevaVenta.fechaPago << " "
                  << nuevaVenta.puntosAcumulados << endl;

    archivoVentas.close();

    cout << "La venta ha sido registrada exitosamente." << endl;
}

// Funci�n para mostrar el movimiento de compras
void mostrarMovimientoCompras() {
    ifstream archivoCompras("compras.txt");
    if (!archivoCompras) {
        cerr << "No se pudo abrir el archivo de compras." << endl;
        return;
    }

    cout << "Movimiento de Compras:" << endl;
    string linea;
    while (getline(archivoCompras, linea)) {
        istringstream stream(linea);
        Compra compra;

        stream >> compra.codigoProveedor;
        stream >> compra.pesoCilindro;
        stream >> compra.cantidadCilindros;
        stream >> compra.precioUnitario;
        stream.ignore(); // Ignorar el espacio antes de la cadena
        getline(stream, compra.nombreProveedor, ' ');
        stream >> compra.fechaCompra;

        cout << "Proveedor: " << compra.nombreProveedor 
             << ", Peso: " << compra.pesoCilindro 
             << ", Cantidad: " << compra.cantidadCilindros 
             << ", Precio Unitario: " << compra.precioUnitario 
             << ", Fecha: " << compra.fechaCompra << endl;
    }

    archivoCompras.close();
}

// Funci�n para mostrar el movimiento de ventas
void mostrarMovimientoVentas() {
    ifstream archivoVentas("ventas.txt");
    if (!archivoVentas) {
        cerr << "No se pudo abrir el archivo de ventas." << endl;
        return;
    }

    cout << "Movimiento de Ventas:" << endl;
    string linea;
    while (getline(archivoVentas, linea)) {
        istringstream stream(linea);
        Venta venta;

        stream >> venta.codigoCliente;
        stream.ignore(); // Ignorar el espacio

        getline(stream, venta.tipoCliente, ' ');
        getline(stream, venta.nombreCliente, ' ');

        stream >> venta.pesoCilindro;
        stream >> venta.cantidadCilindros;
        stream >> venta.precioUnitario;
        stream >> venta.fechaVenta;
        stream >> venta.tipoVenta;
        stream >> venta.fechaPago;

        cout << "Codigo de cliente: " << venta.codigoCliente
		<< ", Cliente: " << venta.nombreCliente  
             << ", Peso: " << venta.pesoCilindro
             << ", Cantidad: " << venta.cantidadCilindros 
             << ", Precio Unitario: " << venta.precioUnitario
             << ", Fecha de Venta: " << venta.fechaVenta 
             << ", Tipo de Venta: " << venta.tipoVenta
             << ", Fecha de Pago: " << venta.fechaPago << endl;
    }

    archivoVentas.close();
}

// Funci�n para mostrar el listado de clientes por c�digo
void mostrarListadoClientesCodigo() {
    int codigoBuscado;
    cout << "Ingrese el cpdigo del cliente a buscar: ";
    cin >> codigoBuscado;

    ifstream archivoVentas("ventas.txt");
    if (!archivoVentas) {
        cerr << "No se pudo abrir el archivo de ventas." << endl;
        return;
    }

    cout << "Listado de Clientes por Codigo:" << endl;
    string linea;
    while (getline(archivoVentas, linea)) {
        istringstream stream(linea);
        Venta venta;

        stream >> venta.codigoCliente;
        stream.ignore(); // Ignorar el espacio

        getline(stream, venta.tipoCliente, ' ');
        getline(stream, venta.nombreCliente, ' ');
        stream >> venta.pesoCilindro;
        stream >> venta.cantidadCilindros;
        stream >> venta.precioUnitario;
        stream >> venta.fechaVenta;
        stream >> venta.tipoVenta;
        stream >> venta.fechaPago;

        if (venta.codigoCliente == codigoBuscado) {
            cout << "Codigo: " << venta.codigoCliente 
                 << ", Tipo: " << venta.tipoCliente
                 << ", Nombre: " << venta.nombreCliente 
                 << ", Peso: " << venta.pesoCilindro
                 << ", Cantidad: " << venta.cantidadCilindros
                 << ", Precio Unitario: " << venta.precioUnitario
                 << ", Fecha de Venta: " << venta.fechaVenta 
                 << ", Tipo de Venta: " << venta.tipoVenta
                 << ", Fecha de Pago: " << venta.fechaPago << endl;
            return; // Se encontr� el cliente, se puede salir del bucle
        }
    }

    cout << "No se encontro ning�n cliente con el c�digo ingresado." << endl;

    archivoVentas.close();
}



// Funci�n para mostrar el listado de clientes con cr�dito
void mostrarListadoClientesCredito() {
    ifstream archivoVentas("ventas.txt");
    if (!archivoVentas) {
        cerr << "No se pudo abrir el archivo de ventas." << endl;
        return;
    }

    cout << "Listado de Clientes con Cr�dito:" << endl;
    string linea;
    while (getline(archivoVentas, linea)) {
        istringstream stream(linea);
        Venta venta;

        stream >> venta.codigoCliente;
        stream.ignore(); // Ignorar el espacio

        getline(stream, venta.tipoCliente, ' ');
        getline(stream, venta.nombreCliente, ' ');
        stream >> venta.pesoCilindro;
        stream >> venta.cantidadCilindros;
        stream >> venta.precioUnitario;
        stream >> venta.fechaVenta;
        stream >> venta.tipoVenta;
        stream >> venta.fechaPago;

        if (venta.tipoVenta == "credito") {
            cout << "Cliente: " << venta.nombreCliente 
                 << ", Tipo: " << venta.tipoCliente
                 << ", Fecha de Pago: " << venta.fechaPago << endl;
        }
    }

    archivoVentas.close();
}



// Funci�n para mostrar el listado de clientes con puntos acumulados

void mostrarListadoClientesPuntos() {
    ifstream archivoVentas("ventas.txt");
    if (!archivoVentas) {
        cerr << "No se pudo abrir el archivo de ventas." << endl;
        return;
    }

    cout << "Listado de Clientes con Puntos Acumulados:" << endl;
    string linea;
    while (getline(archivoVentas, linea)) {
        istringstream stream(linea);
        Venta venta;

        stream >> venta.codigoCliente;
        stream.ignore(); // Ignorar el espacio

        getline(stream, venta.tipoCliente, ' ');
        getline(stream, venta.nombreCliente, ' ');

        stream >> venta.pesoCilindro;
        stream >> venta.cantidadCilindros;
        stream >> venta.precioUnitario;
        stream >> venta.fechaVenta;
        stream >> venta.tipoVenta;
        stream >> venta.fechaPago;
        stream >> venta.puntosAcumulados; // Leer los puntos acumulados

        if (venta.puntosAcumulados > 0) {
            cout << "Cliente: " << venta.nombreCliente
                 << ", Tipo: " << venta.tipoCliente
                 << ", Puntos Acumulados: " << venta.puntosAcumulados << endl;
        }
    }

    archivoVentas.close();
}


int main() {
    char opcion;
    do {
        cout << "MENU:" << endl;
        cout << "1. Registrar compra" << endl;
        cout << "2. Registrar venta" << endl;
        cout << "3. Registrar cliente" << endl;
        cout << "4. Mostrar movimiento de compras" << endl;
        cout << "5. Mostrar movimiento de ventas" << endl;
        cout << "6. Mostrar listado de clientes por codigo" << endl;
        cout << "7. Mostrar listado de clientes con credito" << endl;
        cout << "8. Mostrar listado de clientes con puntos acumulados" << endl;
        cout << "9. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case '1':
                registrarCompra();
                break;
            case '2':
                registrarVenta();
                break;
            case '3':
                registrarCliente();
                break;
            case '4':
                mostrarMovimientoCompras();
                break;
            case '5':
                mostrarMovimientoVentas();
                break;
            case '6':
                mostrarListadoClientesCodigo();
                break;
            case '7':
                mostrarListadoClientesCredito();
                break;
            case '8':
                mostrarListadoClientesPuntos();
                break;
            case '9':
                cout << "Saliendo del programa." << endl;
                break;
            default:
                cout << "Opcion no valida. Intente de nuevo." << endl;
                break;
        }
    } while (opcion != '9');

    return 0;
}

