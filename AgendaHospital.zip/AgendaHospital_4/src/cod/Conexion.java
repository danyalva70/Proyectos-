
package cod;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


    
      public class Conexion {
      public Connection _conexion;   
    Statement _st; //Esto sirve para abrir la conexion 
    ResultSet _rs; // para extraer la informacion
    
    public Connection CrearConexion() {
        try {

            if (_conexion == null || _conexion.isClosed()) {             
                _conexion = DriverManager.getConnection("jdbc:mysql://localhost/HospitalCitas" ,"root","123456"); //aca es donde hacemos la conexion
                _conexion.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED); //la insolacion permite dar paso a las conexiones uno por uno
                _conexion.setAutoCommit(false);
            } 
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error al intentar conectar a la base de datos", JOptionPane.ERROR_MESSAGE);
        }
        return _conexion;
    }

    public ResultSet EjecutarConsulta(String query) {
        _st = null;
        _rs = null;
        CrearConexion();
        try {
            _st = _conexion.createStatement(); // apertura la conexion a la BD
            _rs = _st.executeQuery(query);    
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error al ejecutar consulta", JOptionPane.ERROR_MESSAGE);
            
        }
        return _rs;
    }

    public String EjecutarEscalar(String query) {
        _st = null;
        _rs = null;
        CrearConexion();
        try {
            _st = _conexion.createStatement(); // apertura la conexion
            _rs = _st.executeQuery(query); // extrae la conexion
            if (_rs.next()) {
                return _rs.getString(1);
            }
        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error al ejecutar consulta", JOptionPane.ERROR_MESSAGE);

        } finally {
            CerrarConexion();
        }
        return "";
    }

    public String Ejecutar(String query) {
        String resultado = "";
        try {
            CrearConexion();
            _conexion.setAutoCommit(false);
            Statement st = _conexion.createStatement();
            st.execute(query);
            _conexion.commit();
        } catch (SQLException ex) {
            resultado = ex.toString();
            JOptionPane.showMessageDialog(null, ex, "Error al intentar conectar a la base de datos", JOptionPane.ERROR_MESSAGE);
            try {
                _conexion.rollback(); // si en caso no se puede conectar con la base de datos el rollback lo que hace es que no toca la base de datos
            } catch (SQLException ex1) {
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex1);
            }
        } finally {
             
                CerrarConexion();
        }
        return resultado;
    }

   
    public void CerrarConexion() {
        try {
            if (_conexion != null || !_conexion.isClosed()) {
                _conexion.close();
                System.gc();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex, "Error al cerrar la Base de Datos", JOptionPane.ERROR_MESSAGE);
        }

    }
    }
  
