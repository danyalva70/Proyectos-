/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cod;
import cod.Conexion;
import java.sql.ResultSet;

/**
 *
 * @author danya
 */
public class Mediamentos implements menu{
        private String consulta;
    private String Mensaje;
    private Conexion con;
    private String codigo;
    private String nombre;
    private String precio;
    private String cantidad;
    
    

    public Mediamentos() {
        con = new Conexion();
    }
    public String getMensaje() {
        return Mensaje;
    }

    public String getcodigo() {
        return codigo;
    }

    public void setcodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getprecio() {
        return precio;
    }

    public void setprecio(String precio) {
        this.precio = precio;
    }

    public String getcantidad() {
        return cantidad;
    }

    public void setcantidad(String cantidad) {
        this.cantidad = cantidad;
    }
  

    

   @Override
    public boolean Guardar() {
        try {
            consulta = "insert into medicamento (codigo, Nombre, precio, cantidad) values "
                    + "('" + codigo + "', '" + nombre +"', '" + precio +"', '" + cantidad + ")";
            String respuesta = con.Ejecutar(consulta);
            if (respuesta.equals("")) {
                return true;
            } else {
                Mensaje = "Error la informacion no se guardo, " + respuesta;
                return false;
            }
        } catch (Exception x) {
            Mensaje = "Error la informacion no se guardo, " + x.toString();
            return false;
        }
    }

    @Override
    public ResultSet verInformacion() {
        try {
            ResultSet rs;
            rs = con.EjecutarConsulta("SELECT codigo, nombre, precio, cantidad from medicamento ");
            return rs;
        } catch (Exception x) {
            return null;
        }
    }

    @Override
    public boolean Borrar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean Actualizar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   

        

    
}
