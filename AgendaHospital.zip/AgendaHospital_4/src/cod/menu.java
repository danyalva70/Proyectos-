
package cod;
 
import java.sql.ResultSet;

public interface menu {
     
    public abstract boolean Guardar();
    public abstract boolean Borrar();
    public abstract boolean Actualizar();
    public abstract ResultSet verInformacion();
    
}
