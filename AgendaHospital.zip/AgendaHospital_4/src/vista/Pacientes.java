
package vista;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import cod.Paciente;
/**
 *
 * @author danya
 */
public class Pacientes extends javax.swing.JInternalFrame {
    DefaultTableModel modelo;
    Paciente paciente;
   
    public Pacientes() {
        initComponents();
         modelo = new DefaultTableModel();
        modeloTabla();
        paciente = new Paciente();
    }
     private void modeloTabla() {
        // Definir el modelo para la tabla con los nombres de las columnas
        modelo.addColumn("Expediente");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido");
        modelo.addColumn("Edad");
        modelo.addColumn("Genero");
        modelo.addColumn("Direccion");
        modelo.addColumn("Telefono");
        
        tbl.setModel(modelo);
    }
     
private void AgregarInformacion() {
    // Obtén los valores de los campos
    String expediente = txtexpediente.getText();
    String nombre = txtnombre.getText();
    String apellido = txtapellido.getText();
    String edad = txtedad.getText();
    String genero = txtgenero.getSelectedItem().toString();
   String direccion = txtdireccion.getText();
   String telefono = txttel.getText();

    // Valida que los campos no estén vacíos
    if (nombre.isEmpty() ||  apellido.isEmpty() ) {
        JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos");
        return;
    }

   
    // Agrega la información a la tabla
    DefaultTableModel model = (DefaultTableModel) tbl.getModel();
    model.addRow(new Object[]{expediente, nombre, apellido, edad, genero, direccion, telefono});
}

private void guardar(){
    paciente.setDireccion(txtdireccion.getText());
    paciente.setapellido(txtapellido.getText());
    paciente.setNombre(txtnombre.getText());
    paciente.setTelefono(txttel.getText());
    paciente.setEdad(txtedad.getText());
    paciente.setExpediente(txtexpediente.getText());
    if (paciente.Guardar()){
         JOptionPane.showMessageDialog(null, "Datos Guardados", "Ok" , JOptionPane.OK_OPTION);
         limpiarCampos();
         AgregarInformacion();
    }
    else
         JOptionPane.showMessageDialog(null,  paciente.getMensaje(),  "Error",JOptionPane.ERROR_MESSAGE);
   
}




    // Método para seleccionar una fila y mostrar los datos en los campos
private void SelectRow() {
    int selectedRow = tbl.getSelectedRow();
    if (selectedRow >= 0) {
        txtexpediente.setText(modelo.getValueAt(selectedRow, 0).toString()); // Elimina esta línea si ya no usas txtcod.
        txtnombre.setText(modelo.getValueAt(selectedRow, 1).toString());
        txtapellido.setText(modelo.getValueAt(selectedRow, 2).toString());
        txtedad.setText(modelo.getValueAt(selectedRow, 3).toString());
        txtgenero.setSelectedItem(modelo.getValueAt(selectedRow, 4).toString());
        txtdireccion.setText(modelo.getValueAt(selectedRow, 5).toString());
        txttel.setText(modelo.getValueAt(selectedRow, 6).toString());

    }
}

    // Método para limpiar los campos
    private void limpiarCampos() {
        txtexpediente.setText("");
        txtnombre.setText("");
        txtapellido.setText("");
        txtedad.setText("");
        txtgenero.setSelectedIndex(0);
        txtdireccion.setText("");
        txttel.setText("");
    }
    
    private void ActualizarInformacion() {
    // Obtener los valores de los campos de texto
    String nombre = txtnombre.getText();
    String apellido = txtapellido.getText();
    String edad = txtedad.getText();
    String genero = txtgenero.getSelectedItem().toString();
    String direccion = txtdireccion.getText();
    String telefono = txttel.getText();

    // Validar que los campos de precio venta y costo contengan números válidos
  
        // Obtener la fila seleccionada
        int selectedRow = tbl.getSelectedRow();
        
        if (selectedRow >= 0) {
            // Actualizar los valores en la tabla con los nuevos datos ingresados en los campos de texto
            modelo.setValueAt(nombre, selectedRow, 1);
            modelo.setValueAt(apellido, selectedRow, 2);
            modelo.setValueAt(edad, selectedRow, 3);
            modelo.setValueAt(genero, selectedRow, 4);
            modelo.setValueAt(direccion, selectedRow, 5);
            modelo.setValueAt(telefono, selectedRow, 6);
            // Mensaje de confirmación
            javax.swing.JOptionPane.showMessageDialog(this, "Datos actualizados correctamente.");
        } else {
            // Mensaje si no se ha seleccionado ninguna fila
            javax.swing.JOptionPane.showMessageDialog(this, "Por favor selecciona una fila para actualizar.");
        }
    
}
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtnombre = new javax.swing.JTextField();
        lblnombre3 = new javax.swing.JLabel();
        txtapellido = new javax.swing.JTextField();
        txttel = new javax.swing.JTextField();
        txtedad = new javax.swing.JTextField();
        btbAgregar = new javax.swing.JButton();
        txtgenero = new javax.swing.JComboBox<>();
        lblnombre1 = new javax.swing.JLabel();
        txtexpediente = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl = new javax.swing.JTable();
        lblnombre2 = new javax.swing.JLabel();
        txtdireccion = new javax.swing.JTextField();
        lblapellido = new javax.swing.JLabel();
        lblciclo = new javax.swing.JLabel();
        btnActualizar = new javax.swing.JButton();
        lblsec = new javax.swing.JLabel();
        lblnombre = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        txtnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnombreActionPerformed(evt);
            }
        });

        lblnombre3.setText("No. telefonico");

        txttel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttelActionPerformed(evt);
            }
        });

        btbAgregar.setText("Agregar");
        btbAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbAgregarActionPerformed(evt);
            }
        });

        txtgenero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "F", "M" }));
        txtgenero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtgeneroActionPerformed(evt);
            }
        });

        lblnombre1.setText("No. Expediente");

        txtexpediente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtexpedienteActionPerformed(evt);
            }
        });

        tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl);

        lblnombre2.setText("Direccion");

        txtdireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdireccionActionPerformed(evt);
            }
        });

        lblapellido.setText("Apellido");

        lblciclo.setText("Edad");

        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        lblsec.setText("Genero");

        lblnombre.setText("Nombre:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btbAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(108, 108, 108)
                .addComponent(btnActualizar)
                .addGap(145, 145, 145))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(lblnombre1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtexpediente))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(lblapellido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblciclo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblsec, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(lblnombre, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(lblnombre2, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtnombre)
                                .addComponent(txtapellido)
                                .addComponent(txtedad, javax.swing.GroupLayout.DEFAULT_SIZE, 109, Short.MAX_VALUE)
                                .addComponent(txtdireccion))
                            .addComponent(txtgenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(lblnombre3, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txttel)))
                .addGap(48, 48, 48)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 499, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnActualizar)
                    .addComponent(btbAgregar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblnombre1)
                    .addComponent(txtexpediente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblnombre))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtapellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblapellido))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblciclo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblsec)
                    .addComponent(txtgenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtdireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblnombre2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txttel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblnombre3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnombreActionPerformed

    private void txttelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttelActionPerformed

    private void btbAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbAgregarActionPerformed
        AgregarInformacion();
        guardar();
        limpiarCampos();// TODO add your handling code here:
    }//GEN-LAST:event_btbAgregarActionPerformed

    private void txtgeneroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtgeneroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtgeneroActionPerformed

    private void txtexpedienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtexpedienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtexpedienteActionPerformed

    private void tblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblMouseClicked
        SelectRow();        // TODO add your handling code here:
    }//GEN-LAST:event_tblMouseClicked

    private void txtdireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdireccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdireccionActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        ActualizarInformacion();
        limpiarCampos();// TODO add your handling code here:
    }//GEN-LAST:event_btnActualizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbAgregar;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblapellido;
    private javax.swing.JLabel lblciclo;
    private javax.swing.JLabel lblnombre;
    private javax.swing.JLabel lblnombre1;
    private javax.swing.JLabel lblnombre2;
    private javax.swing.JLabel lblnombre3;
    private javax.swing.JLabel lblsec;
    private javax.swing.JTable tbl;
    private javax.swing.JTextField txtapellido;
    private javax.swing.JTextField txtdireccion;
    private javax.swing.JTextField txtedad;
    private javax.swing.JTextField txtexpediente;
    private javax.swing.JComboBox<String> txtgenero;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txttel;
    // End of variables declaration//GEN-END:variables
}
