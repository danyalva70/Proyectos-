
package vista;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import cod.VentasM;

 

public class Ventas extends javax.swing.JInternalFrame  {
 DefaultTableModel modelo;
 VentasM ventasmedicamentos;


    public Ventas () {
        initComponents();
         modelo = new DefaultTableModel();
        modeloTabla();
        ventasmedicamentos = new VentasM();
       
    }
    private void modeloTabla (){
     
     modelo.addColumn("producto");
     modelo.addColumn("precio");
     modelo.addColumn("cantidad");
    modelo.addColumn("subtotal");
     
     tbl.setModel(modelo);
     
     }
    private void guardar(){
    ventasmedicamentos.setproducto(txtproducto.getText());
    ventasmedicamentos.setCantidad(txtcantidad.getText());
    ventasmedicamentos.setprecio(txtprecio.getText());
    
    if (ventasmedicamentos.Guardar()){
         JOptionPane.showMessageDialog(null, "Datos Guardados", "Ok" , JOptionPane.OK_OPTION);
         limpiarCampos();
    }
    else
         JOptionPane.showMessageDialog(null,  ventasmedicamentos.getMensaje(),  "Error",JOptionPane.ERROR_MESSAGE);
   
}
    public void limpiarCampos(){
    txtproducto.setText("");
    txtprecio.setText("");
    txtcantidad.setText("");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtproducto = new javax.swing.JTextField();
        txtcantidad = new javax.swing.JTextField();
        txtprecio = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl = new javax.swing.JTable();
        agregar = new javax.swing.JButton();
        lbltotal = new javax.swing.JButton();
        Pventas = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("VENTAS MEDICAMENTOS ");

        jLabel1.setText("Producto");

        jLabel2.setText("Cantidad");

        jLabel3.setText("Precio");

        tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbl);

        agregar.setText("Agregar al Carrito");
        agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarActionPerformed(evt);
            }
        });

        lbltotal.setText("Calcular Total");
        lbltotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lbltotalActionPerformed(evt);
            }
        });

        Pventas.setText("Procesar Ventas");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(41, 41, 41)
                                .addComponent(txtcantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txtproducto, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(56, 56, 56)
                                        .addComponent(txtprecio, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(213, 213, 213)
                                .addComponent(agregar)
                                .addGap(64, 64, 64)
                                .addComponent(lbltotal)
                                .addGap(67, 67, 67)
                                .addComponent(Pventas)))
                        .addGap(0, 4, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtproducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(agregar)
                    .addComponent(lbltotal)
                    .addComponent(Pventas))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtcantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtprecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(46, 46, 46)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(100, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lbltotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lbltotalActionPerformed
         double total = 0;
    for (int i = 0; i < tbl.getRowCount(); i++) {
        total += (double) tbl.getValueAt(i, 3);
    }
    lbltotal.setText("Total: $" + total);

    }//GEN-LAST:event_lbltotalActionPerformed

    private void agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarActionPerformed
        
 //AgregarInfomacion();    
 guardar();
         String producto = txtproducto.getText();
         int cantidad = Integer.parseInt(txtcantidad.getText());
         double  precio = Double.parseDouble(txtprecio.getText());
         double subtotal = cantidad* precio;
        
        /* if (producto.isEmpty()|| cantidad.isEmpty()|| precio.isEmpty()){
                JOptionPane.showMessageDialog(this,"por favor, complete los campos");
         return;
         } */
    DefaultTableModel model = (DefaultTableModel) tbl.getModel();
    model.addRow(new Object[]{producto, precio, cantidad, subtotal });
         

limpiarCampos();

    }//GEN-LAST:event_agregarActionPerformed



        
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Pventas;
    private javax.swing.JButton agregar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton lbltotal;
    private javax.swing.JTable tbl;
    private javax.swing.JTextField txtcantidad;
    private javax.swing.JTextField txtprecio;
    private javax.swing.JTextField txtproducto;
    // End of variables declaration//GEN-END:variables

}
